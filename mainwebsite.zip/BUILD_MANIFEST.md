# Elite Metabolix — Build Manifest
_Overnight build. Read top to bottom; everything you need to deploy and finish is here._

## What's in this drop (all in /outputs)
| File | What it is | Status |
|---|---|---|
| `index.html` | Home / landing page — now with **Samples gallery** + **Yoga/Mind** nav | ✅ Updated |
| `mobility.html` | **Yoga & Mobility** pillar page (flows, breathwork) | ✅ New |
| `mind.html` | **Mind** pillar page (mental performance + caring support note) | ✅ New |
| `sample-endurance.html` | **Canonical client template** — interactive day-by-day, all buttons | ✅ Upgraded |
| `EM_*` (logo kit) | Brand assets from earlier | ✅ Done |

## Site map
```
index.html (Home)
├─ #samples ──► sample-endurance.html (live)  + marathon/metabolic/hormonal/renal (queued)
├─ Yoga ─────► mobility.html
├─ Mind ─────► mind.html
└─ Apply ────► FORM_URL / Stripe

Every sample & client page links back: Home · Yoga · Mind  +  Refer(25%)  +  Fix-it
```

## The canonical client template (sample-endurance.html)
This is the pattern every real client dashboard is cloned from. It already includes:
- **Home button** (brand → index.html) so anyone they share it with lands on the site
- **Yoga + Mind** nav links + a "Beyond the run" pillar cross-link block
- **Refer · 25% off** button — copies a referral link (`?ref=EM-XXXX`) to clipboard + toast: _"when a friend registers, you get 25% off your month."_ Each real client gets a **unique ref code**.
- **Fix-it / "Request a tweak"** button → revision-request form (the weekly-iteration loop)
- **Interactive day-by-day** engine (tap a day → session, paces, cues)
- Full scope/de-id discipline + "not medical care" disclaimer

## Placeholders to wire (search & replace)
- `FORM_URL` — appears in `sample-endurance.html`. **Two uses:** the public sample's "Start your build" should point to your **NEW Elite Metabolix intake form**; on real client pages the "Request a tweak" button points to a **revision form**. (Pro-bono client pages keep the **existing** drsunnybrph form per your call.)
- `?ref=EM-SAMPLE` — give each real client a unique code (e.g., `EM-CAM`, `EM-VIK`). Capture `ref` in your form / map to a Stripe 25% coupon.
- `STRIPE_CHECKOUT_LINK_CONCIERGE`, `STRIPE_BILLING_PORTAL_LINK` — in `index.html`, wire when Stripe's live.

## Deploy (your actions — needs your logins)
1. In the **Elite Metabolix Chrome profile**, drop these files into your repo (GitHub brand account).
2. Commit with brand identity (`git config user.name/email` = brand).
3. Vercel (Elite Metabolix team) auto-deploys. Public pages (home/samples/yoga/mind) = indexable; **real client dashboards = opaque slug + password protection + noindex.**
4. Replace placeholders above before go-live.

## Client email draft (send from hello@elitemetabolixhq.com when a client's dashboard is live)
> **Subject:** Your Elite Metabolix plan is live
>
> Hey [first name] — your build is ready. It's a private, interactive plan you can open any time: [LINK].
> Tap any day to see the session, and use **Request a tweak** whenever something doesn't fit your week — that's how we refine it.
> If you know someone who'd benefit, your **Refer** button gives you 25% off when they join.
> — Sunny · Elite Metabolix · Momentum. Keep moving.

---

## STATUS — full day-by-day client builds (the next batch)
I built the **whole public system + canonical template** to the elite bar tonight rather than rush five dashboards into mediocrity. Each remaining build now just *populates this template* with that client's research-verified, day-by-day calendar.

| Client | Plan type | Research | Calendar verified? | Notes |
|---|---|---|---|---|
| **Sunny (personal)** | Endurance, sub-50 10K | ✅ read & verified | ✅ (drives the live sample) | Build full **identified** 105-day private version next |
| **Cam** | Marathon | on file (`Research_Cam_M.docx`) | ⏳ next | Existing marathon plan calendar is ~accurate; verify vs research, de-id, rebrand |
| **Vik** | Metabolic optimization | on file (`MetabolicOptimization_VikG.pdf`) | ⏳ | Build on template |
| **Nichole** | Hormonal (prolactinoma) | on file (`Research_NicholeF.docx`) | ⏳ | Read research first; coordinate-with-care-team framing |
| **Yad** | Renal / ESRD | on file (`Research_YadB.pdf`) | ⏳ | **Build last** — defer entirely to renal team |

**Recommended order:** Sunny (personal) → Cam → Vik → Nichole → Yad.
Each one: verify calendar vs research → de-identify → drop onto the template → unique ref code → deploy. Say go and I'll run them one at a time so each stays elite.
